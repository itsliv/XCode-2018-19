//
//  ViewController.swift
//  Dad Jokes
//
//  Created by Paul Way on 1/13/19.
//  Copyright © 2019 Paul Way. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var button: UIButton!
    
    var joke:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func getJoke(_ sender: Any) {
        
        let urlStr = "https://icanhazdadjoke.com/"
        let url = URL(string: urlStr)
        var request = URLRequest(url: url!)
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            print("Sending Request")
            if response != nil {
                let str = String(data:data!, encoding:.utf8)!
                print(str)
                let jsonDecoder = JSONDecoder()
                let jokeData = try! jsonDecoder.decode(DadJoke.self, from: data!)
                self.joke = jokeData.joke
                DispatchQueue.main.async {
                    self.textView.text = self.joke
                    return
                }
            }
        })
        task.resume()
    }
}
struct DadJoke:Codable{
    let id:String
    let joke:String
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case joke = "joke"
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(String.self, forKey: CodingKeys.id)
        self.joke = try container.decode(String.self, forKey: CodingKeys.joke)
    }
    
    func encode(to encoder: Encoder) throws {
    }
}

