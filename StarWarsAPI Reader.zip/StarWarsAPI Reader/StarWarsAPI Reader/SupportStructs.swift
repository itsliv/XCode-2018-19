//
//  SupportStructs.swift
//  StarWarsAPI Reader
//
//  Created by Paul Way on 1/13/19.
//  Copyright © 2019 Paul Way. All rights reserved.
//

import Foundation

//let categories = [
//    "People",
//    "Films",
//    "Starships",
//    "Vehicles",
//    "Species",
//    "Planets"]





struct Starships: Codable {
    let name: String
    enum CodingKeys: String, CodingKey {
        case name = "name"
    }
    init(from decoder: Decoder) throws {
        let valueContainer = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try valueContainer.decode(String.self, forKey: CodingKeys.name)
    }
}
