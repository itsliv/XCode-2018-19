//
//  PeopleTableViewController.swift
//  StarWarsAPI Reader
//
//  Created by Paul Way on 1/13/19.
//  Copyright © 2019 Paul Way. All rights reserved.
//

import UIKit

class PeopleTableViewController: UITableViewController {

    var data:[People]?
    let category = "people"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        
    }
    
    func loadData(){
        let urlStr = "http://swapi.co/api/"+category+"/"
        let url = URL(string: urlStr)
        var request = URLRequest(url: url!)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            print("Sending Request")
            if response != nil {
                                let str = String(data:data!, encoding:.utf8)!
                                print(str)
                let jsonDecoder = JSONDecoder()
                let responseData = try! jsonDecoder.decode(PeopleResponseData.self, from: data!)
                self.data = responseData.people
                DispatchQueue.main.async {
                    // Refresh the Table Data
                    print("Refreshing Table Data")
                    self.tableView.reloadData()
                    return
                }
            }
        })
        task.resume()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if let count = data?.count {
            return count
        }
        return 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = data![indexPath.row].name
        // Configure the cell...
        return cell
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
struct PeopleResponseData : Codable{
    let people: [People]
    enum CodingKeys: String, CodingKey {
        case results = "results"
    }
    init(from decoder: Decoder) throws {
        let valueContainer = try decoder.container(keyedBy: CodingKeys.self)
        self.people = try valueContainer.decode([People].self, forKey: CodingKeys.results)
    }
    func encode(to encoder: Encoder) throws {
    }
}
struct People: Codable {
    let name: String
    let gender: String
    enum CodingKeys: String, CodingKey {
        case name = "name"
        case gender = "gender"
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decode(String.self, forKey: CodingKeys.name)
        self.gender = try container.decode(String.self, forKey: CodingKeys.gender)
    }
    
    func encode(to encoder: Encoder) throws {
    }
}
