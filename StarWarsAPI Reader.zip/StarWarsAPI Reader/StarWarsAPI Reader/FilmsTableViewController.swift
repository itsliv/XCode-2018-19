//
//  FilmsTableViewController.swift
//  StarWarsAPI Reader
//
//  Created by Paul Way on 1/13/19.
//  Copyright © 2019 Paul Way. All rights reserved.
//

import UIKit

class FilmsTableViewController: UITableViewController {
    
    var data:[Films]?
    let category = "films"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        
    }
    
    func loadData(){
        let urlStr = "http://swapi.co/api/"+category+"/"
        let url = URL(string: urlStr)
        var request = URLRequest(url: url!)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            print("Sending Request")
            if response != nil {
                //                let str = String(data:data!, encoding:.utf8)!
                //                print(str)
                let jsonDecoder = JSONDecoder()
                let filmResponseData = try! jsonDecoder.decode(FilmResponseData.self, from: data!)
                self.data = filmResponseData.films
                DispatchQueue.main.async {
                    // Refresh the Table Data
                    print("Refreshing Table Data")
                    self.tableView.reloadData()
                    return
                }
            }
        })
        task.resume()
    }
    
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if let count = data?.count {
            return count
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = data![indexPath.row].title
        return cell
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
struct FilmResponseData : Codable{
    let films: [Films]
    enum CodingKeys: String, CodingKey {
        case results = "results"
    }
    init(from decoder: Decoder) throws {
        let valueContainer = try decoder.container(keyedBy: CodingKeys.self)
        self.films = try valueContainer.decode([Films].self, forKey: CodingKeys.results)
    }
    func encode(to encoder: Encoder) throws {
    }
}
struct Films: Codable {
    let title: String
    let release_date: String
    
    init(from decoder: Decoder) throws {
        let valueContainer = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try valueContainer.decode(String.self, forKey: CodingKeys.title)
        self.release_date = try valueContainer.decode(String.self, forKey: CodingKeys.release_date)
    }
}
