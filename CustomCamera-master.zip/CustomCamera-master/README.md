# iOS Swift Tutorial: Basic Custom Camera App - AVFoundation

In this tutorial you are going to create a custom camera interface. You can use it for your own camera driven apps and add exactly the style you want.

[Video on YouTube](https://youtu.be/Zv4cJf5qdu0)


